/*!

* sense-calendar-heatmap - Qlik Sense Visualization Extension with a diverging color scale. The values are displayed as colored cells per day. Days are arranged into columns by week, then grouped by month and years.
*
* @version v0.2.5
* @link https://github.com/stefanwalther/qsCalendarHeatmap
* @author Stefan Walther
* @license MIT
*/


/*global
 define,
 console
 */
define(["jquery","underscore","angular","qlik","./properties","./initialproperties","./lib/js/extensionUtils","text!./lib/css/main.css","text!./swr-calendarheatmap.ng.html","./lib/directives/swr-simpletable/swr-simpletable","./lib/directives/swr-calendarview/swr-calendarview"],function($,_,angular,qlik,props,initProps,extensionUtils,cssContent,ngTemplate){"use strict";function transformData(hc){var data=[];if(hc)for(var counter=-1,i=0;i<hc.qHyperCube.qDataPages[0].qMatrix.length;i++)if(counter++,!hc.qHyperCube.qDataPages[0].qMatrix[i][0].qIsEmpty&&!hc.qHyperCube.qDataPages[0].qMatrix[i][0].qIsNull){var dateKey=hc.qHyperCube.qDataPages[0].qMatrix[i][0].qText,val=parseFloat(hc.qHyperCube.qDataPages[0].qMatrix[i][1].qNum),valToolTip=_.isEmpty(hc.qHyperCube.qDataPages[0].qMatrix[i][1].qText)?"Value: "+val:hc.qHyperCube.qDataPages[0].qMatrix[i][1].qText;data[counter]={Date:dateKey,Measure:val,ToolTip:valToolTip}}return data}return extensionUtils.addStyleToHeader(cssContent),{definition:props,initialProperties:initProps,snapshot:{canTakeSnapshot:!0},template:ngTemplate,controller:["$scope",function($scope){function createHyperCube(){if($scope.hyperCube&&(app.destroySessionObject?app.destroySessionObject($scope.hyperCube.qInfo.qId).then(function(reply){angular.noop()}):extensionUtils.destroyObj(app,$scope.hyperCube.qInfo.qId)),$scope.layout.props&&!_.isEmpty($scope.layout.props.uniqueDay)&&!_.isEmpty($scope.layout.props.uniqueDayValue)){var cubeDef={qDimensions:[{qDef:{qFieldDefs:[$scope.layout.props.uniqueDay],qSortCriterias:[{qSortByAscii:1}]}}],qMeasures:[{qDef:{qDef:"="+$scope.layout.props.uniqueDayValue}},{qDef:{qDef:"="+(_.isEmpty($scope.layout.props.uniqueDayTooltip)?"''":$scope.layout.props.uniqueDayTooltip)}}],qInterColumnSortOrder:[0,1],qInitialDataFetch:[{qTop:0,qLeft:0,qHeight:1500,qWidth:3}]};app.createCube(cubeDef,function(reply){$scope.hyperCube=reply,$scope.data=transformData(reply)})}}var app=qlik.currApp();$scope.hyperCube=null,$scope.data=null,$scope.props=$scope.layout.props,$scope.$watchCollection("layout.props",function(){createHyperCube()})}]}});